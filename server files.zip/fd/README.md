Nessa pasta será armazenado as fotos das pessoas cadastradas
